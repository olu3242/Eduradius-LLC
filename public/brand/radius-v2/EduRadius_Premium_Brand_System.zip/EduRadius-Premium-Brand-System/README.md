# EduRadius LLC - Premium identity system

Edition 03 / Radius identity + website assets / 15 November 2026

## Start here
Open EduRadius_Premium_Brandbook.pdf. It contains 21 pages covering the brand foundation, master logo, logo variants, clear space and scale, misuse, palette, contrast, typography, typesetting, graphic language, voice, digital application, presentations and social, stationery and merchandise, and handoff.

## Asset folders
- assets/logos: scalable SVG masters plus transparent PNGs. The primary Radius logo follows the selected and refined circular radial emblem. The previous merged ER identity is superseded. Added variants include stacked, solid white, solid symbol and micro symbol. Do not reconstruct the wordmark from a font.
- assets/applications: seven layouts, each as EDITABLE (live text) and OUTLINED (font-independent paths) SVG. Includes business card front/back, US Letter letterhead, 16:9 presentation cover, square social post, social banner and merchandise symbol artwork.
- assets/brand-tokens.css and assets/colors.json: precise digital color specifications and web typography tokens.
- assets/email-signature.html: editable text-based email signature.
- fonts: original Manrope and DM Sans variable fonts plus their OFL licenses. Install these before editing the live-text application SVGs. Some editors may need you to select the installed font explicitly. The logo wordmark is a fixed vector trace of the approved artwork. It must not be recreated with a typed font.
- assets/mockups: AI-generated visual concepts for stationery and merchandise. These are illustration/reference images, not manufacturing artwork. Use the logo master files when creating a production proof.

## Editing and output
1. Duplicate an editable SVG before making changes. Install the fonts and replace every bracketed placeholder with verified information.
2. Keep the original logo shape and proportions. Use the single-color artwork for embroidery, engraving, one-color screen printing and debossing.
3. Digital output: use HEX/RGB, sRGB, and transparent PNG or SVG. Test at the final size.
4. Print: CMYK values in the book are approximate starting conversions. Agree on the ICC profile, stock, finish, bleed and color proof with the supplier. No Pantone, embroidery-thread, calibrated CMYK or factory-ready claim is made.
5. Business card: 3.5 x 2 inch trim, with 0.125 inch bleed each side. The SVG canvas is 3.75 x 2.25 inches. Trim is inset 37.5 viewBox units at each edge; keep important content at least another 37.5 units inside trim. Add crop marks only as your supplier requests.
6. Letterhead: US Letter (8.5 x 11 inch), office-print layout with no bleed. Presentation is 1920 x 1080; square post is 1080 x 1080; banner is 1584 x 396. Merchandise dimensions are proposed starting points, not a manufacturer's approved imprint area.
7. Before release: review spelling, contact details, company identifiers, photo rights, clear space, size and contrast. Obtain a vendor proof before ordering physical goods. This pack does not order merchandise or change a website.

## Color usage
Forest #173F35 / Sage #88A76D / Lime #D3EB9E / Paper #F8F8F2.
Support: body #667468 / line #DDE5D6.
Forest on Paper = 10.95:1. Forest on Lime = 8.98:1. Forest on Sage = 4.33:1; avoid for normal-sized text. Sage on Paper = 2.53:1; use as decoration, not reading text. These are calculated sRGB contrast ratios, not a full accessibility certification.

## Sources and notices
Manrope source: https://github.com/google/fonts/tree/main/ofl/manrope
DM Sans source: https://github.com/google/fonts/tree/main/ofl/dmsans
Font licenses: fonts/Manrope-OFL.txt and fonts/DMSans-OFL.txt
Contrast reference: https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum/
Selected logo: Radius concept A, approved in this conversation and refined on 14 November 2026. The previous ER logo family is superseded.
Generated mockup prompts: PROMPTS.txt.

## Rebuilding the reference PDF (optional)
The included build_brandbook.py is the editable layout source. It requires Python with reportlab, Pillow, fonttools and pymupdf, plus Node with sharp. Run from this folder: python3 build_brandbook.py. Install the Python dependencies with your usual environment manager and install sharp with npm. The script writes generated font instances and temporary renders to work/, and the PDF to output/. The included, verified PDF is the reference deliverable. SVG masters remain the scalable production assets; the PDF uses high-resolution renders to preserve the logo silhouette across PDF readers.

This is a design system and supplier handoff proposal, not a trademark clearance or registration.

## Website imagery and lifecycle — Edition 03
The assets/website folder adds the supplied illustrative service and sector images, education hero, editable six-stage workflow SVG, matching PNG and approved brand tokens. Read assets/website/README.txt for provenance, scale limits, and placements. The alternative supplied palette is superseded. The original upload is retained in assets/website-source for reference. The 21-page identity brandbook remains the approved identity reference.
