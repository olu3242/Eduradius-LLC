from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont as RLFont
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image,ImageOps,ImageDraw
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import fitz, re, json, shutil, zipfile, math, html, subprocess, os
R=Path(__file__).resolve().parent
O=R/'output'; A=R/'assets'; W=1040; H=720; M=56
O.mkdir(exist_ok=True);(R/'work').mkdir(exist_ok=True)
from fontTools.varLib.instancer import instantiateVariableFont
for family in ['Manrope','DMSans']:
 for weight in [400,500,600,700]:
  target=R/'work'/f'{family}-{weight}.ttf'
  if not target.exists():
   src=TTFont(str(R/'fonts'/f'{family}.ttf'));axes={'wght':weight}
   if family=='DMSans':axes['opsz']=14
   instantiateVariableFont(src,axes,inplace=False).save(target)
O.mkdir(exist_ok=True);(R/'work').mkdir(exist_ok=True)
from fontTools.varLib.instancer import instantiateVariableFont
for family in ['Manrope','DMSans']:
 for weight in [400,500,600,700]:
  target=R/'work'/f'{family}-{weight}.ttf'
  if not target.exists():
   src=TTFont(str(R/'fonts'/f'{family}.ttf'));axes={'wght':weight}
   if family=='DMSans':axes['opsz']=14
   instantiateVariableFont(src,axes,inplace=False).save(target)
F='#173F35'; S='#88A76D'; L='#D3EB9E'; P='#F8F8F2'; G='#667468'; LINE='#DDE5D6'; RED='#9B4D3E'
for fam in ['Manrope','DMSans']:
 for wt in [400,500,600,700]:pdfmetrics.registerFont(RLFont(f'{fam}{wt}',str(R/'work'/f'{fam}-{wt}.ttf')))
base=(A/'logos/eduradius-logo.svg').read_text(); sym=(A/'logos/eduradius-symbol.svg').read_text()
# Radius masters are frozen SVG paths traced from the approved artwork.
# Editable application templates include actual logo vectors and live type.
fontfiles={'Manrope':TTFont(str(R/'work/Manrope-500.ttf')),'ManropeBold':TTFont(str(R/'work/Manrope-700.ttf')),'DMSans':TTFont(str(R/'work/DMSans-400.ttf'))}
def tx(txt,x,y,size=24,color=F,fam='DMSans',weight=400):
 return f'<text x="{x}" y="{y}" font-family="{'DM Sans' if fam=='DMSans' else fam}" font-weight="{weight}" font-size="{size}" fill="{color}">{html.escape(txt)}</text>'
def logo_svg(x,y,width=320,reverse=False,icon=False):
 name='eduradius-symbol-white.svg' if icon and reverse else 'eduradius-symbol.svg' if icon else 'eduradius-logo-reverse.svg' if reverse else 'eduradius-logo.svg'
 src=(A/'logos'/name).read_text();vb='170 160' if icon else '639 160'
 inner=re.sub(r'<svg[^>]*>','',src,count=1).replace('</svg>','')
 return f'<svg x="{x}" y="{y}" width="{width}" height="{width*(160/170 if icon else 160/639)}" viewBox="0 0 {vb}">{inner}</svg>'
def arc_svg(w,h,col=LINE):
 return ''.join(f'<circle cx="{w}" cy="{h}" r="{r}" fill="none" stroke="{col}" stroke-width="2"/>' for r in [160,260,360])
def make_svg(name,w,h,body,physical=None):
 dim=f'width="{physical[0]}" height="{physical[1]}"' if physical else f'width="{w}" height="{h}"'
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" {dim} viewBox="0 0 {w} {h}"><title>EduRadius {name}</title>{body}</svg>'
 dest=A/'applications'/f'{name}-editable.svg';dest.write_text(svg)
 # Outline live text for portable, font-independent artwork; editable counterpart retained.
 import xml.etree.ElementTree as ET
 ET.register_namespace('','http://www.w3.org/2000/svg');rt=ET.fromstring(svg)
 for parent in rt.iter():
  for child in list(parent):
   if child.tag.endswith('}text'):
    attrs=child.attrib;fam=attrs.get('font-family','DMSans').replace(' ','');font=fontfiles['ManropeBold' if attrs.get('font-weight')=='700' else fam]
    gs=font.getGlyphSet(); cmap=font.getBestCmap(); sc=float(attrs['font-size'])/font['head'].unitsPerEm;x=float(attrs['x']);y=float(attrs['y']);g=ET.Element('{http://www.w3.org/2000/svg}g')
    for ch in ''.join(child.itertext()):
     gn=cmap.get(ord(ch),'space');pen=SVGPathPen(gs);gs[gn].draw(pen)
     if pen.getCommands():ET.SubElement(g,'{http://www.w3.org/2000/svg}path',{'d':pen.getCommands(),'transform':f'translate({x} {y}) scale({sc} {-sc})','fill':attrs.get('fill',F)})
     x+=gs[gn].width*sc
    idx=list(parent).index(child);parent.remove(child);parent.insert(idx,g)
 (A/'applications'/f'{name}-outlined.svg').write_text(ET.tostring(rt,encoding='unicode'))
 return svg
front=make_svg('business-card-front',1125,675,f'<rect width="1125" height="675" fill="{F}"/>'+arc_svg(1125,675,'#315748')+logo_svg(160,222,805,True),('3.75in','2.25in'))
back=make_svg('business-card-back',1125,675,f'<rect width="1125" height="675" fill="{P}"/>'+logo_svg(65,45,420)+tx('[Name]',80,320,54,fam='Manrope',weight=700)+tx('[Role / team]',80,374,29,color=G)+f'<path d="M80 432H1045" stroke="{LINE}" stroke-width="2"/>'+tx('[Email]',80,493,28)+tx('[Phone]',80,540,28)+tx('AI with purpose.',710,540,28,color=G),('3.75in','2.25in'))
letter=make_svg('letterhead-US-letter',816,1056,f'<rect width="816" height="1056" fill="white"/>'+logo_svg(50,42,255)+tx('[Date]',56,183,13)+tx('[Recipient / organization]',56,230,14)+tx('[Subject]',56,290,22,fam='Manrope',weight=700)+tx('[Letter body - replace with your correspondence]',56,342,14)+f'<path d="M56 966H760" stroke="{LINE}"/>'+tx('EduRadius LLC',56,994,11)+tx('[Email]  |  [Phone]  |  [Website]',410,994,11,color=G),('8.5in','11in'))
slide=make_svg('presentation-cover-16x9',1920,1080,f'<rect width="1920" height="1080" fill="{P}"/>'+arc_svg(1920,1080)+logo_svg(96,65,470)+tx('AI with purpose.',96,484,110,fam='Manrope',weight=700)+tx('Progress with people.',96,622,110,fam='Manrope',weight=700)+tx('[Presentation title / audience]',102,823,32,color=G)+tx('[Date]',102,943,23,color=G)+f'<circle cx="1750" cy="145" r="13" fill="{L}"/>')
social=make_svg('social-post-square',1080,1080,f'<rect width="1080" height="1080" fill="{F}"/>'+arc_svg(1080,1080,'#315748')+logo_svg(68,65,400,True)+tx('Make AI work.',78,465,92,color=P,fam='Manrope',weight=700)+tx('For your people.',78,582,82,color=P,fam='Manrope',weight=700)+tx('For your mission.',78,689,82,color=L,fam='Manrope',weight=700)+tx('CONSULTING / GOVERNANCE / ADOPTION / LEARNING',80,949,20,color=P))
banner=make_svg('social-banner',1584,396,f'<rect width="1584" height="396" fill="{F}"/>'+logo_svg(60,58,410,True)+tx('AI with purpose.',650,169,62,color=P,fam='Manrope',weight=700)+tx('Progress with people.',650,247,62,color=L,fam='Manrope',weight=700))
# Production artwork only, no manufactured object silhouettes.
make_svg('merchandise-symbol-artwork',300,300,logo_svg(20,20,260,icon=True))
# Exact, useful technical tokens.
def rgb(h):return [int(h[i:i+2],16) for i in (1,3,5)]
def lum(h):
 a=[v/255 for v in rgb(h)];a=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a]
 return sum(a[i]*v for i,v in enumerate([.2126,.7152,.0722]))
def ratio(a,b):a,b=sorted([lum(a),lum(b)],reverse=True);return (a+.05)/(b+.05)
colors={'forest':F,'sage':S,'lime':L,'paper':P,'body':G,'line':LINE}
(A/'colors.json').write_text(json.dumps({k:{'hex':v,'rgb':rgb(v)} for k,v in colors.items()},indent=2))
(A/'brand-tokens.css').write_text(':root {\n'+''.join(f'  --eduradius-{k}: {v};\n' for k,v in colors.items())+'  --font-display: "Manrope", Arial, sans-serif;\n  --font-body: "DM Sans", Arial, sans-serif;\n  --space-unit: 8px;\n}\n')
(A/'email-signature.html').write_text('''<table cellpadding="0" cellspacing="0" style="font-family:Arial,sans-serif;color:#173F35"><tr><td style="padding-right:20px;border-right:2px solid #88A76D"><strong style="font-size:20px">EduRadius LLC</strong></td><td style="padding-left:20px;font-size:13px"><strong>[Name]</strong><br>[Role / team]<br><span style="color:#667468">[Email] | [Phone] | [Website]</span></td></tr></table>''')
# PDF layout system: generous top-down coordinates and a consistent baseline.
C=canvas.Canvas(str(R/'work/layout.pdf'),pagesize=(W,H));C.setTitle('EduRadius LLC - Premium Brandbook');C.setAuthor('EduRadius LLC');placements=[];page=0
CHECKS=[]
def box(x,y,w,h,col,stroke=None,r=0):
 C.setFillColor(HexColor(col));C.setStrokeColor(HexColor(stroke or col));C.setLineWidth(.65)
 (C.roundRect if r else C.rect)(x,H-y-h,w,h,*( [r] if r else []),stroke=bool(stroke),fill=1)
def line(x,y,x2,y2,col=LINE,width=.6,dash=None):
 C.setStrokeColor(HexColor(col));C.setLineWidth(width);C.setDash(dash or []);C.line(x,H-y,x2,H-y2);C.setDash([])
def text(txt,x,y,size=13,font='DMSans400',col=F,tracking=0):
 C.saveState();C.setFillColor(HexColor(col));C.setFont(font,size)
 obj=C.beginText(x,H-y-size);obj.setCharSpace(tracking);obj.textLine(txt);C.drawText(obj);C.restoreState()
 # Keep authored text inside the page; content boxes are reviewed in rendered sheets too.
 wid=pdfmetrics.stringWidth(txt,font,size)+max(0,len(txt)-1)*tracking
 if x+wid>W-25 or y+size>H-25:CHECKS.append((page,txt,x,y,wid))
def para(txt,x,y,width=400,size=13,col=G,font='DMSans400',leading=None):
 sty=ParagraphStyle('body',fontName=font,fontSize=size,leading=leading or size*1.55,textColor=HexColor(col),spaceAfter=0)
 p=Paragraph(txt,sty);ww,hh=p.wrap(width,600);p.drawOn(C,x,H-y-hh);
 if x+width>W-30 or y+hh>H-50:CHECKS.append((page,'PARAGRAPH: '+txt[:40],x,y,hh))
 return hh

def heading(lines,x=M,y=104,size=45,col=F):
 for i,t in enumerate(lines.split('\n')):text(t,x,y+i*size*1.15,size,'Manrope500',col)

def label(txt,x=M,y=70,col=G):text(txt.upper(),x,y,8,'DMSans600',col,1.65)
def logo(x,y,w,kind='logo',rotate=0,stretch=1):
 names={'logo':'eduradius-logo.svg','reverse':'eduradius-logo-reverse.svg','mono':'eduradius-logo-monochrome.svg','icon':'eduradius-symbol.svg','whiteicon':'eduradius-symbol-white.svg','solidicon':'eduradius-symbol-solid.svg','micro':'eduradius-symbol-micro.svg','stack':'eduradius-logo-stacked.svg','solidwhite':'eduradius-logo-solid-white.svg'}
 f=A/'logos'/names[kind];v=re.search(r'viewBox="([^"]+)"',f.read_text()).group(1).split();ar=float(v[3])/float(v[2]);h=w*ar*stretch
 placements.append((page,str(f),(x,y,x+w,y+h),rotate));return h

def art_svg(name,x,y,w,h):placements.append((page,str(A/'applications'/f'{name}-outlined.svg'),(x,y,x+w,y+h),0))
def photo(file,x,y,w,h):
 im=Image.open(A/'mockups'/file);crop=ImageOps.fit(im,(int(w*2),int(h*2)),method=Image.Resampling.LANCZOS);C.drawImage(ImageReader(crop),x,H-y-h,w,h,mask='auto')
def footer(dark=False):
 col='#A6B89E' if dark else G;line(M,675,W-M,675,'#355B4B' if dark else LINE)
 text('EDURADIUS LLC / BRAND SYSTEM',M,688,7,'DMSans500',col,1)
 text('V2.0 / 14 NOVEMBER 2026',440,688,7,'DMSans400',col,.7)
 text(f'{page:02d}',956,686,9,'DMSans600',col)
def start(section,bg=P):
 global page
 if page:C.showPage()
 page+=1;box(0,0,W,H,bg);label(section,y=29,col='#A6B89E' if bg==F else G)
 footer(bg==F)
def note(txt,y=625):para(txt,M,y,W-2*M,9,G,leading=14)

# 01 / Cover
start('Brandbook / Identity & applications',F)
logo(M,88,315,'reverse');heading('Purpose.\nMade tangible.',M,238,78,P)
para('A considered identity for AI consulting, governance, adoption, training and education.',M,460,470,17,'#B7CAA4')
for r in [90,155,220]:
 C.setStrokeColor(HexColor('#355E4A'));C.setLineWidth(.7);C.circle(875,H-400,r,stroke=1,fill=0)
logo(775,293,185,'whiteicon');box(956,128,12,12,L,r=6)
text('EDURADIUS LLC',M,610,10,'DMSans600',P,2);text('PREMIUM IDENTITY SYSTEM / RADIUS EDITION 02',505,612,8,'DMSans500','#B7CAA4',1.4)
# 02 / Contents
start('The system at a glance');heading('Built for consistency.\nDesigned to be used.',size=48)
para('One identity, expressed with care across every touchpoint. This book defines the visual rules and supplies practical templates for putting them to work.',M,248,440,14)
sections=[('01','Foundation & expression','03-07'),('02','Color & accessible pairings','08-09'),('03','Typography & layout','10-11'),('04','Visual language & voice','12-13'),('05','Digital, print & merchandise','14-19'),('06','Handoff & next steps','20-21')]
for i,(n,t,p) in enumerate(sections):
 y=112+i*78;line(565,y+62,984,y+62);text(n,565,y+14,10,'DMSans500',S);text(t,606,y+12,16,'Manrope500');text(p,940,y+16,10,col=G)
box(M,451,438,131,'#EAF0E1');label('CREATIVE DIRECTION',M+22,471);para('Quiet confidence. Human purpose.\n<br/>Precise detail. Practical progress.',M+22,497,380,18,F,'Manrope500',26)
note('Edition 02 applies the selected Radius identity. Application layouts use placeholders where company contact details are not verified.')
# 03 / Foundation
start('01 / Brand foundation');heading('Intelligence,\nwith purpose.',size=55)
para('EduRadius LLC helps organizations explore and adopt AI through clear strategy, responsible governance, and practical education.',M,267,430,17)
label('BRAND PROMISE',M,409);para('Make AI work. For your people.\n<br/>For your mission.',M,436,430,24,F,'Manrope500',33)
services=[('01','AI consulting','Turn a useful question into a clear direction.'),('02','AI governance','Bring ownership, oversight and review into the process.'),('03','AI adoption','Prepare the people and workflows behind useful change.'),('04','Training & education','Build understanding and practical confidence.')]
for i,(n,t,b) in enumerate(services):
 y=118+i*117;line(565,y-9,984,y-9);text(n,565,y+4,10,col=S);text(t,604,y,22,'Manrope500');para(b,604,y+37,360,12)
note('Voice: clear, considered, practical, human. Describe real capabilities without implying unverified certifications, clients or procurement eligibility.')
# 04 / Logo meaning
start('01 / The master logo');heading('A clear purpose.\nAn expanding radius.',size=45)
logo(80,311,850)
para('The radial emblem suggests an expanding E: one circular silhouette opened by tapered negative space. Its forest-green shape gives the identity a clear, confident signature.',565,112,410,14)
line(M,545,984,545)
for i,(t,b) in enumerate([('RADIUS','The circular silhouette gives the identity a recognizable center.'),('CLARITY','Tapered apertures create an open, distinctive E-like form.'),('REACH','The outward rhythm suggests knowledge extending into practice.')]):
 x=M+i*319;label(t,x,572);para(b,x,596,285,11)
# 05 / Logo system
start('01 / Logo family');heading('One identity.\nThe right expression.',size=40)
para('Use supplied artwork. The wordmark is fixed outlined lettering; do not recreate it using a typed font.',585,111,390,13)
box(56,252,554,167,'#FFFFFF',LINE);logo(81,283,500);label('01 / PRIMARY RADIUS',77,398)
box(56,439,554,176,F);logo(81,471,500,'reverse');label('02 / REVERSED FOR DARK SURFACES',77,590,'#B7CAA4')
box(634,252,350,167,'#FFFFFF',LINE);logo(663,280,292,'mono');label('03 / SINGLE COLOR',656,398)
box(634,439,161,176,'#EAF0E1');logo(654,458,120,'icon');label('04 / SYMBOL',652,590)
box(813,439,171,176,'#FFFFFF',LINE);logo(840,452,115,'stack');label('05 / STACKED',830,590)
# 06 / Spacing
start('01 / Clear space & scale');heading('Give the logo\nroom to breathe.',size=43)
para('Minimum clear space X equals one-eighth of the symbol diameter. Keep type, borders and other marks outside this zone. Measure from visible artwork, not the SVG canvas.',581,112,390,13)
# Logo outer guide based on visible source artwork x30.5, y18 to x614, y129.5.
x=70;y=310;w=860;scale=w/639;gx=x+10*scale;gy=y+13.7*scale;gw=619*scale;gh=132.6*scale;xx=(132.6/8)*scale
logo(x,y,w)
for bx,by,bw,bh in [(gx,gy,gw,gh),(gx-xx,gy-xx,gw+2*xx,gh+2*xx)]:
 line(bx,by,bx+bw,by,S,dash=[3,3]);line(bx,by+bh,bx+bw,by+bh,S,dash=[3,3]);line(bx,by,bx,by+bh,S,dash=[3,3]);line(bx+bw,by,bx+bw,by+bh,S,dash=[3,3])
text('X',gx-xx+4,gy-xx-18,10,col=G);text('X',gx+gw+8,gy+gh/2-8,10,col=G)
line(M,529,984,529)
for i,(t,b) in enumerate([('HORIZONTAL LOGO','160 px digital / 40 mm print minimum.'),('SYMBOL','32 px digital / 10 mm print minimum.'),('SMALL REPRODUCTION','Use the solid symbol at small sizes; keep every aperture open.')]):
 x=M+i*319;label(t,x,552);para(b,x,580,278,12)
note('Minimums are starting specifications. Test the actual output at final size; increase the mark if the wordmark or apertures lose definition.',632)
# 07 / Usage
start('01 / Logo integrity');heading('Precision is part\nof the brand.',size=42)
para('Keep the original proportions, colors and letterforms. When a surface is difficult, change the placement or use the approved single-color version.',591,111,380,13)
examples=[('Do not stretch','Distorted proportions'),('Do not rotate','The primary logo sits level'),('Do not recolor','Use the defined palette'),('Do not add effects','No glows, shadows or bevels'),('Do not crowd','Respect the clear-space zone'),('Do not lose contrast','Switch to the correct reverse')]
for i,(t,b) in enumerate(examples):
 x=56+(i%3)*319;y=258+(i//3)*178;box(x,y,290,148,'#FFFFFF',LINE)
 if i==0:logo(x+24,y+16,240,stretch=1.5)
 elif i==1:logo(x+24,y+11,240,rotate=15)
 elif i==2:
  colfile=A/'logos/usage-recolor-example.svg';colfile.write_text(base.replace(F,'#AA5E48').replace(S,'#DEBA91'));placements.append((page,str(colfile),(x+24,y+20,x+264,y+80),0))
 elif i==3:logo(x+27,y+25,240);logo(x+24,y+22,240)
 elif i==4:logo(x+14,y+22,240);line(x+4,y+32,x+280,y+32,RED,1)
 else:box(x+15,y+17,260,72,S);logo(x+24,y+22,240,'reverse')
 line(x+14,y+98,x+27,y+111,RED,1.3);line(x+27,y+98,x+14,y+111,RED,1.3);text(t,x+38,y+96,11,'DMSans600',F);text(b,x+15,y+124,9,col=G)
# 08 / Palette
start('02 / The color system');heading('Grounded in forest.\nLifted by lime.',size=45)
para('A restrained palette keeps the brand recognizable. Use paper and forest for most surfaces; sage supports the system and lime adds a precise accent.',595,112,380,13)
for i,(name,h,role) in enumerate([('Forest',F,'Structure / type'),('Sage',S,'Supporting fields'),('Lime',L,'Small accents'),('Paper',P,'Primary light canvas')]):
 x=56+i*237;box(x,272,217,224,h,LINE if h==P else None);text(name,x+17,293,20,'Manrope500',P if h==F else F);text(h,x+17,457,12,'DMSans600',P if h==F else '#102F25')
 rr,gg,bb=rgb(h);k=1-max(rr,gg,bb)/255;cmy=[0,0,0] if k==1 else [(1-v/255-k)/(1-k) for v in [rr,gg,bb]]
 text('RGB  '+str(rr)+' / '+str(gg)+' / '+str(bb),x,516,10,col=G);text('CMYK*  '+' / '.join(str(round(v*100)) for v in cmy+[k]),x,540,9,col=G);text(role,x,565,10,'DMSans500')
for i,(fraction,col) in enumerate([(0.55,P),(.30,F),(.10,S),(.05,L)]):
 startx=56+928*sum(v for v,c in [(0.55,P),(.30,F),(.10,S),(.05,L)][:i]);box(startx,604,928*fraction,13,col,LINE)
note('* CMYK values are approximate starting conversions, not calibrated print targets. Proof using the printer\'s ICC profile and chosen stock. Suggested balance: 55% paper / 30% forest / 10% sage / 5% lime.',635)
# 09 / Contrast
start('02 / Pair color with care');heading('Readable by design.',size=48)
para('Use the pairings below for normal reading text. Sage and lime are supporting colors, not default body-text colors on light backgrounds.',M,199,500,13)
pairs=[('Forest on Paper',F,P),('Paper on Forest',P,F),('Forest on Lime',F,L),('Forest on Sage',F,S),('Body grey on Paper',G,P),('Sage on Paper',S,P)]
for i,(n,fg,bg) in enumerate(pairs):
 x=56+(i%3)*319;y=294+(i//3)*151;r=ratio(fg,bg);box(x,y,290,123,bg,LINE if bg==P else None);text('Aa',x+17,y+12,34,'Manrope500',fg);text(f'{r:.2f}:1',x+191,y+19,17,'Manrope500',fg);text(n,x+17,y+72,11,'DMSans500',fg);text('NORMAL TEXT: '+('PASS' if r>=4.5 else 'AVOID'),x+17,y+98,8,'DMSans600',fg,1)
note('Calculated from the exact sRGB values. Normal text targets 4.5:1; large text targets 3:1 under WCAG contrast guidance. A palette test is not a full accessibility assessment. Source: W3C Contrast (Minimum), linked in the handoff notes.',632)
# 10 / Type
start('03 / Typography');heading('Clarity, in every letter.',size=47)
text('Aa',M,220,150,'Manrope500',F);text('Manrope',360,254,49,'Manrope500');label('DISPLAY / 500-700',364,330)
para('Use for headlines, section titles, short statements and key numbers. Set with quiet confidence: concise lines, open spacing and minimal punctuation.',365,360,580,15)
line(M,473,984,473);text('Aa',M,498,92,'DMSans400');text('DM Sans',360,508,33,'DMSans500');label('READING / 400-600',364,558)
para('Use for body copy, forms, tables and supporting information. Build hierarchy with size and weight before adding color.',365,583,580,13)
# 11 / Scale
start('03 / Typesetting & layout');heading('A deliberate rhythm.',size=45)
scale_rows=[('Hero','64 / 70 px','40 / 46 px','Manrope 500'),('Section title','40 / 48 px','30 / 38 px','Manrope 500'),('Subheading','24 / 32 px','22 / 30 px','Manrope 600'),('Body','16 / 26 px','16 / 26 px','DM Sans 400'),('Caption','12 / 18 px','12 / 18 px','DM Sans 500')]
label('ROLE',56,218);label('DESKTOP',260,218);label('MOBILE',453,218);label('TYPEFACE',656,218)
for i,(role,desktop,mobile,fam) in enumerate(scale_rows):
 y=257+i*55;line(56,y+39,984,y+39);text(role,56,y,15,'DMSans500');text(desktop,260,y+2,13);text(mobile,453,y+2,13);text(fam,656,y+2,13,col=G)
box(56,566,928,61,'#EAF0E1');para('8 px spacing unit / 12-column desktop grid / 24 px gutters / 24 px mobile side margins.<br/>Body measure: roughly 55-75 characters. Use sentence case. Avoid fully justified text.',75,581,885,11,F)
note('Sizes are starting tokens, not fixed rules for every format. For print, start at 10-12 pt body text and confirm legibility in a physical proof.',638)
# 12 / Visual language
start('04 / Graphic language');heading('The radius,\nused with restraint.',size=44)
para('Use cropped arcs as a framing device. A small lime accent may add emphasis outside the logo. Geometry should create focus, not compete with the message.',M,268,385,14)
box(535,108,449,355,F)
C.saveState();clip=C.beginPath();clip.rect(535,H-108-355,449,355);C.clipPath(clip,stroke=0,fill=0)
for r in [70,125,185,245]:
 C.setStrokeColor(HexColor('#3B614D'));C.setLineWidth(.7);C.circle(984,H-463,r,stroke=1,fill=0)
C.restoreState();box(905,163,11,11,L,r=5.5);text('Human purpose.',565,220,27,'Manrope500',P);text('Intelligent progress.',565,258,27,'Manrope500',L)
for i,(t,b) in enumerate([('GRAPHICS','One arc system per composition. Thin lines, generous empty space. Keep decorative accents outside the logo.'),('ICONS','Simple outline icons, consistent optical weight, no competing styles.'),('PHOTOGRAPHY','Human, natural, purposeful. Real work and tactile materials; no robot-head cliches.')]):
 x=56+i*319;label(t,x,518);para(b,x,547,280,12)
# 13 / Voice
start('04 / Language & expression');heading('Sound like a capable\nhuman partner.',size=44)
para('Lead with the need. Name the action. Explain what happens next. Use direct language people can understand without specialist vocabulary.',M,244,420,14)
label('CORE MESSAGE',M,394);para('AI with purpose.<br/>Progress with people.',M,424,440,31,F,'Manrope500',40)
rows=[('CLEAR','"Start with a useful business problem."','Avoid vague promises of transformation.'),('PRACTICAL','"Define a pilot, an owner and a review point."','Describe a concrete next step.'),('RESPONSIBLE','"Review the evidence before expanding."','Make human accountability visible.'),('CREDIBLE','"Discuss the qualifications this scope requires."','Publish only verified claims and identifiers.')]
for i,(t,quote,n) in enumerate(rows):
 y=115+i*124;label(t,570,y);para(quote,570,y+25,400,18,F,'Manrope500',25);para(n,570,y+79,400,10)
note('Service terminology: AI consulting / AI governance / AI adoption / training and education. Short campaign copy may use "learning"; retain the full service name in formal capability materials.')
# 14 / Digital
start('05 / Digital application');heading('A calm, purposeful\ndigital presence.',size=43)
para('Carry the brand into a clear hierarchy: a useful headline, one primary action and evidence that can be reviewed.',M,246,335,13)
# Large browser composition
box(433,108,551,373,'#FFFFFF',LINE);box(433,108,551,24,'#E9EEE0');
for ix in range(3):box(445+ix*11,117,4,4,S,r=2)
logo(455,148,155);text('Capabilities   Teaming   About',715,161,7,col=G)
text('Make AI work.',459,233,30,'Manrope500');text('For your people.',459,271,30,'Manrope500');text('For your mission.',459,309,30,'Manrope500');para('Clear strategy. Responsible adoption.<br/>Practical learning.',460,361,240,9)
box(460,417,132,29,F);text('Request a briefing',475,426,8,'DMSans500',P)
box(823,218,125,167,'#EAF0E1');logo(845,245,80,'icon')
# Phone
box(759,404,170,225,F,r=14);box(767,413,154,207,P,r=9);logo(776,425,125);text('AI with',779,486,21,'Manrope500');text('purpose.',779,514,21,'Manrope500');box(779,570,129,28,F);text('Request a briefing',792,579,8,'DMSans500',P)
label('APPLICATION PRINCIPLES',56,438);para('Use real text, visible focus states and captions for video. Keep forms short. Label draft or unverified company information clearly.',56,468,328,12)
note('Illustrative responsive design layout, not a screenshot or a claim of live Site functionality.',638)
# 15 / Campaign templates
start('05 / Presentations & social');heading('Recognizable,\nbefore the first word.',size=42)
para('Use the same family across decks, briefing materials and social content. Keep one idea per cover or post.',586,112,390,13)
art_svg('presentation-cover-16x9',56,265,599,337);label('16:9 PRESENTATION COVER',56,622)
art_svg('social-post-square',681,265,303,303);label('SQUARE SOCIAL POST',681,590)
# 16 / Stationery atmosphere
start('05 / Stationery collection');photo('stationery-concept.png',0,0,W,650)
box(0,0,415,127,P);label('05 / STATIONERY CONCEPT',M,27);heading('Quietly professional.',M,64,28)
box(0,614,W,44,P);para('Illustrative AI-generated mockup. For accurate logo geometry, editable text and dimensions, use the supplied artwork templates rather than extracting artwork from this photograph.',M,625,928,9,G,leading=13)
# 17 / Stationery artwork
start('05 / Stationery specifications');heading('Thoughtful in hand.',size=45)
para('Build trust through details: a generous margin, a restrained palette and legible contact information.',M,198,410,13)
art_svg('business-card-front',56,285,390,234);art_svg('business-card-back',56,436,390,234)
# Deliberately overlap cards as a designed stack; back extends to 670, footer needs relocation.
# Cover lower part of second card and position a smaller separate preview instead.
# Actual preview placed at a scale with both designs fully in the content area.
placements.pop();placements.pop();art_svg('business-card-front',56,284,340,204);art_svg('business-card-back',260,421,340,204)
art_svg('letterhead-US-letter',684,201,268,347)
label('BUSINESS CARD',56,534);para('US trim: 3.5 x 2 in<br/>Bleed: 0.125 in each side<br/>Keep live content 0.125 in inside trim.<br/>Suggested stock: 350-450 gsm uncoated.',56,561,202,10)
label('LETTERHEAD',681,569);para('US Letter: 8.5 x 11 in.<br/>Office-print template, no bleed.<br/>Replace every bracketed field.',681,593,282,10)
# 18 / Merchandise hero
start('05 / Merchandise collection');photo('merchandise-concept.png',0,0,W,650)
box(0,0,439,149,P);label('05 / MERCHANDISE CONCEPT',M,27);heading('Useful objects.\nA considered signature.',M,62,29)
box(0,614,W,44,P);para('Illustrative AI-generated merchandise concept. Product colors, materials and logo treatments require supplier proofs. The photograph is not manufacturing artwork.',M,625,928,9,G,leading=13)
# 19 / Merchandise specs
start('05 / Merchandise placement');heading('Made to be worn.\nBuilt to be used.',size=42)
para('Choose the mark for the process. The Radius identity is single color; use the forest or cream master for embroidery, screen print, engraving or debossing.',M,240,410,13)
# Three exact flat placement illustrations
box(560,112,424,416,'#EDF1E5')
# tote
C.setStrokeColor(HexColor(S));C.setLineWidth(2);C.roundRect(611,H-192-142,173,142,6,stroke=1,fill=0);C.bezier(648,H-194,648,H-125,746,H-125,746,H-194)
logo(632,227,130,'mono');text('TOTE / 180-240 mm',610,354,9,'DMSans600')
# bottle
box(829,201,70,183,F,r=17);box(839,173,50,31,F,r=5);logo(843,258,41,'whiteicon');text('BOTTLE / 20-30 mm',799,407,9,'DMSans600')
# apparel placement sample swatch
box(612,414,172,75,F,r=4);logo(633,425,53,'whiteicon');text('APPAREL / 22-30 mm',612,505,9,'DMSans600')
items=[('POLO / EMBROIDERY','Use a solid symbol, 22-30 mm wide at left chest. Confirm stitch detail and preserve the negative-space apertures.'),('TOTE / SCREEN PRINT','Use the solid horizontal mark, about 180-240 mm wide. Agree ink and substrate with the printer.'),('BOTTLE / ENGRAVING','Use the solid symbol, about 20-30 mm wide. Check the supplier\'s curved imprint area.'),('NOTEBOOK / DEBOSS','Use the solid mark. A 25-40 mm symbol is a useful starting point; approve a material sample.')]
for i,(t,b) in enumerate(items):
 x=56+(i%2)*244;y=381+(i//2)*117;label(t,x,y);para(b,x,y+25,219,10)
note('All placements are proposed starting dimensions. Obtain embroidery digitization, dielines, material samples and a final supplier proof before ordering.',638)
# 20 / Handoff
start('06 / Handoff & production');heading('A system you can\nput to work.',size=43)
for i,(t,b) in enumerate([('01 / CHOOSE THE MASTER','SVG for scalable artwork. PNG for office documents and quick sharing. Use reversed or solid variants for the surface.'),('02 / PERSONALIZE THE TEMPLATE','Install the supplied fonts before editing text. Replace bracketed contact fields and leave the logo geometry untouched.'),('03 / CHECK THE OUTPUT','Review size, clear space, contrast, spelling and image permissions. Confirm any client, registration or certification claim.'),('04 / PROOF BEFORE RELEASE','Request a physical or digital proof. Align color, stock, bleed and imprint size with the supplier before production.')]):
 y=254+i*86;label(t,M,y);para(b,M,y+25,500,11)
box(618,109,366,479,'#EAF0E1');label('INCLUDED IN THE ASSET PACK',640,134)
files=['Master logo family / SVG + PNG','Solid, micro and stacked symbols','Editable + outlined SVG applications','Business cards / letterhead / slide cover','Social post / banner / email signature','Color tokens / CSS + JSON','Manrope + DM Sans fonts & licenses','Mockup imagery / concept references']
for i,t in enumerate(files):text(f'{i+1:02d}',640,179+i*40,9,col=S);text(t,670,177+i*40,11,'DMSans500')
para('Production notes, font sources and use instructions are included in README.md. Keep the master asset folder with every vendor handoff.',640,519,320,10)
note('Source notes: Google Fonts / Manrope and DM Sans (OFL notices included). W3C Contrast (Minimum). The fixed logo paths follow the approved Radius artwork; they are not retyped from a font.',632)
# 21 / Closing
start('EduRadius LLC / Identity in practice',F)
logo(M,93,323,'reverse');heading('Make AI work.\nFor your people.\nFor your mission.',M,247,65,P)
text('CONSULTING / GOVERNANCE / ADOPTION / EDUCATION',M,582,10,'DMSans500','#B7CAA4',1.5)
C.save()
# High-resolution SVG renders preserve the exact silhouette across PDF readers.
# Scalable original SVG masters are included separately in the asset pack.
rasterdir=R/'work/raster';rasterdir.mkdir(exist_ok=True)
unique=list(dict.fromkeys(path for pn,path,rect,rotation in placements))
job=[]
for idx,path in enumerate(unique):
 target=rasterdir/(str(idx)+'.png');job.append({'input':path,'output':str(target),'width':2800})
nodecode="let sharp;try{sharp=require('sharp')}catch{sharp=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/sharp')};let b=[];process.stdin.on('data',x=>b.push(x));process.stdin.on('end',async()=>{for(const j of JSON.parse(Buffer.concat(b).toString())){await sharp(j.input,{density:300}).resize({width:j.width}).png().toFile(j.output)}});"
subprocess.run(['node','-e',nodecode],input=json.dumps(job).encode(),check=True)
rasters={j['input']:j['output'] for j in job}
doc=fitz.open(R/'work/layout.pdf')
for pn,path,rect,rotation in placements:
 if rotation:
  im=Image.open(rasters[path]).rotate(rotation,expand=True,resample=Image.Resampling.BICUBIC);bio=__import__('io').BytesIO();im.save(bio,format='PNG');doc[pn-1].insert_image(fitz.Rect(*rect),stream=bio.getvalue(),keep_proportion=True)
 else:doc[pn-1].insert_image(fitz.Rect(*rect),filename=rasters[path],keep_proportion=False)
final=O/'EduRadius_Premium_Brandbook.pdf';doc.save(final,garbage=4,deflate=True);doc.close()
# Invalid uses are instructional illustrations, not distributable master logos.
(A/'logos/usage-recolor-example.svg').unlink(missing_ok=True)
print(json.dumps({'pages':page,'file':str(final),'text_overflow_checks':CHECKS,'ratios':{n:round(ratio(a,b),2) for n,a,b in pairs}},indent=2))
